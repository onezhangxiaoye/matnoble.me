// Package jsoninfo provides information and functions for marshalling/unmarshalling JSON.
package jsoninfo
