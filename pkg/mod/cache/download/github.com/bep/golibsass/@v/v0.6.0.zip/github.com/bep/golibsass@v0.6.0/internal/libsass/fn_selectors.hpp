#ifndef USE_LIBSASS_SRC
#include "../../libsass_src/src/fn_selectors.hpp"
#endif
