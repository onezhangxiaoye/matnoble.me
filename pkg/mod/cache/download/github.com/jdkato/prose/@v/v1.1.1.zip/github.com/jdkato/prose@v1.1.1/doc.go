// Package prose is a repository of packages related to text processing,
// including tokenization, part-of-speech tagging, and named-entity extraction.
package prose
