package main

const esbuildVersion = "0.6.5"
